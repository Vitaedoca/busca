#include <stdio.h>
#include <string.h>
#include <ctype.h>

void buscaBinariaIntervalo(char v[][101], int n, const char *chave, int *inicio, int *fim) {
    int s = 0, e = n - 1;
    *inicio = -1;
    *fim = -1;

    while (s <= e) {
        int m = (s + e) / 2;
        int cmp = strncasecmp(chave, v[m], strlen(chave));

        if (cmp == 0) {
            *inicio = m;
            *fim = m;
            break;
        } else if (cmp < 0) {
            e = m - 1;
        } else {
            s = m + 1;
        }
    }

    if (*inicio != -1) {

        int i = *inicio - 1;
        while (i >= 0 && strncasecmp(chave, v[i], strlen(chave)) == 0) {
            *inicio = i;
            i--;
        }

        i = *fim + 1;
        while (i < n && strncasecmp(chave, v[i], strlen(chave)) == 0) {
            *fim = i;
            i++;
        }
    }
}

int main() {
    FILE *f = fopen("nomes.txt", "r");
    if (f == NULL) {
        perror("Erro ao abrir o arquivo");
        return 1;
    }

    char tmp[1000][101];
    int i = 0;


    while (fgets(tmp[i++], 100, f));


    fclose(f);

    char chave[101];

    printf("Digite o prefixo de busca: ");
    scanf("%s", chave);

    int inicio, fim;
    buscaBinariaIntervalo(tmp, i, chave, &inicio, &fim);

    if (inicio != -1) {
        for (int i = inicio; i <= fim; i++) {
            printf("%s", tmp[i]);
        }
    } else {
        printf("Nenhum nome encontrado com o prefixo '%s'.\n", chave);
    }

    return 0;
}
